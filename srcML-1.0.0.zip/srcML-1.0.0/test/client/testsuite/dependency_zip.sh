#!/bin/bash

# test framework
source $(dirname "$0")/framework_test.sh

zip --version
