% make 

% srcml --parser-test testsuite
