Documentation
-------------

To generate the man pages for srcml:

1. Install `ronn` via:

```
gem install ronn
```

2. In the build directory

```
cmake ../srcML -DBUILD_CLIENT_DOC=ON
```
